# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=Sphinx Kernel v3.1 by milouk @xda-developers
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=dipper
supported.versions=9,9.0,10,10.0
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=auto;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;


## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;

LD_PATH=/system/lib
if [ -d /system/lib64 ]; then
  LD_PATH=/system/lib64
fi

exec_util() {
  LD_LIBRARY_PATH=/system/lib64 $UTILS $1
}

set_con() {
  exec_util "chcon -h u:object_r:"$1":s0 $2"
  exec_util "chcon u:object_r:"$1":s0 $2"
}

ui_print "           _____       _     _             "
ui_print "          / ____|     | |   (_)            "
ui_print "         | (___  _ __ | |__  _ _ __ __  __ "
ui_print "          \___ \| '_ \| '_ \| | '_ \\ \/ / "
ui_print "          ____) | |_) | | | | | | | |>  <  "
ui_print "         |_____/| .__/|_| |_|_|_| |_/_/\_\ "
ui_print "                | |                        "
ui_print "                |_|                        "
ui_print "$compatibility_string";

## Trim partitions
ui_print " "
ui_print "Triming cache & data partitions..."
fstrim -v /cache;
fstrim -v /data;


ui_print "Decompressing image kernel..."
ui_print "This might take some seconds."


## AnyKernel install
dump_boot;

# ramdisk patch

umount /vendor || true
mount -o rw /dev/block/bootdevice/by-name/vendor /vendor
exec_util "cp -a /tmp/anykernel/ramdisk/init.sphinx.sh /vendor/bin/"
set_con qti_init_shell_exec /vendor/bin/init.sphinx.sh
umount /vendor || true

# end ramdisk changes

ui_print "Regenerating image kernel and installing..."
write_boot;

write_boot;
## end install

